package com.example.trabalho;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNome, etEmail, etIdade, etDisciplina, etNota1, etNota2;
    private Button btnEnviar, btnLimpar;
    private TextView tvResultado;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        etNome = findViewById(R.id.etNome);
        etEmail = findViewById(R.id.etEmail);
        etIdade = findViewById(R.id.etIdade);
        etDisciplina = findViewById(R.id.etDisciplina);
        etNota1 = findViewById(R.id.etNota1);
        etNota2 = findViewById(R.id.etNota2);
        btnEnviar = findViewById(R.id.btnEnviar);
        btnLimpar = findViewById(R.id.btnLimpar);
        tvResultado = findViewById(R.id.tvResultado);

        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validarCampos();
            }
        });

        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                limparCampos();
            }
        });
    }

    private void validarCampos() {
        String nome = etNome.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String idadeStr = etIdade.getText().toString().trim();
        String disciplina = etDisciplina.getText().toString().trim();
        String nota1Str = etNota1.getText().toString().trim();
        String nota2Str = etNota2.getText().toString().trim();

        if (TextUtils.isEmpty(nome)) {
            etNome.setError("O campo de nome está vazio");
            return;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("O email é inválido");
            return;
        }

        int idade;
        try {
            idade = Integer.parseInt(idadeStr);
            if (idade <= 0) {
                etIdade.setError("A idade deve ser um número positivo");
                return;
            }
        } catch (NumberFormatException e) {
            etIdade.setError("A idade deve ser um número válido");
            return;
        }

        float nota1, nota2;
        try {
            nota1 = Float.parseFloat(nota1Str);
            nota2 = Float.parseFloat(nota2Str);

            if (nota1 < 0 || nota1 > 10 || nota2 < 0 || nota2 > 10) {
                Toast.makeText(this, "Notas devem estar entre 0 e 10", Toast.LENGTH_LONG).show();
                return;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Notas devem ser números válidos", Toast.LENGTH_LONG).show();
            return;
        }

        float media = (nota1 + nota2) / 2;
        String status = media >= 6 ? "Aprovado" : "Reprovado";

        String resultado = "Nome: " + nome + "\n"
                + "Email: " + email + "\n"
                + "Idade: " + idade + "\n"
                + "Disciplina: " + disciplina + "\n"
                + "Nota 1º Bimestre: " + nota1 + "\n"
                + "Nota 2º Bimestre: " + nota2 + "\n"
                + "Média: " + media + "\n"
                + "Status: " + status;

        tvResultado.setText(resultado);
        tvResultado.setVisibility(View.VISIBLE);
    }

    private void limparCampos() {
        etNome.setText("");
        etEmail.setText("");
        etIdade.setText("");
        etDisciplina.setText("");
        etNota1.setText("");
        etNota2.setText("");
        tvResultado.setVisibility(View.GONE);
    }
}
